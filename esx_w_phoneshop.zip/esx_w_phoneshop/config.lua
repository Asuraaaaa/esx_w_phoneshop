local Keys = {
	["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57
}

Config = {}

Config.Blip = 184
Config.BlipColor = 3
Config.BlipTaille = 0.8
Config.MarkerType  = 29
Config.MarkerColor = { r = 255, g = 255, b = 255 }





Config.Shops_Config = {
    Positions = {


        {name = 'MagasinDeTelephone', x = -656.88,   y = -857.29,  z = 24.49},

    },
}


Config.Sim = 50
Config.Radio = 125
Config.iPhone11 = 1235
Config.iPhone11Pro = 1635
Config.Gs10 = 950
Config.Gs8 = 450 














